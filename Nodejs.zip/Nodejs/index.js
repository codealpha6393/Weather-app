 const curUrl = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;
    const curResp = await fetch(curUrl);
    const curData = await curResp.json();
    if (curData.cod && curData.cod !== 200) return res.status(400).json(curData);

    // 5 day / 3 hour forecast
    const fUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric`;
    const fResp = await fetch(fUrl);
    const fData = await fResp.json();
    if (fData.cod && fData.cod !== '200') {
      return res.status(400).json(fData);
    }

    const simplified = simplifyForecast(fData.list);
    res.json({ current: curData, forecast: simplified });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'server error' });
  }
});